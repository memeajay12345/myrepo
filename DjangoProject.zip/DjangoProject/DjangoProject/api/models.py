from django.db import models


# Create your models here.

class Role(models.Model):
    roleName = models.CharField(max_length=40)
    

class User(models.Model):
    userName = models.CharField(max_length=40)
    email = models.EmailField()
    password = models.CharField(max_length=40)
    roleObj = models.ForeignKey(Role, on_delete=models.CASCADE, related_name="users", null=True)

    
    def __str__(self):
        return self.userName  


class Ticket(models.Model):
    ticketId = models.CharField(max_length=20, unique=True)
    issue = models.TextField()
    category = models.CharField(max_length=50)
    createdAt = models.DateField(auto_now_add=True)
    isPriority = models.BooleanField(default=False)
    comment = models.TextField()
    ticketStatus = models.CharField(max_length=20, default='new')
    clientObj = models.ForeignKey(User, on_delete=models.CASCADE, related_name="tickets")

    def __str__(self):
        return self.ticketId 
    
