from .models import User

class ProxyUser(User):
    class Meta:
        proxy=True

    @property
    def is_authenticated(self):
        return True  # Because this is a manually authenticated user