from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import *
from rest_framework_simplejwt.tokens import RefreshToken
from .models import User, Ticket, Role
from rest_framework.permissions import IsAuthenticated
from rest_framework import status
# Create your views here.

class loginView(APIView):
    def post(self, request):
        data = request.data
        serializer = LoginSerializer(data=data)
            
        if serializer.is_valid():
            email = serializer.validated_data['email']
            password = serializer.validated_data['password']
                
        
            try:
                user = User.objects.get(email = email)
            except User.DoesNotExist:
                return Response({'error': 'User not found'}, status=404)
                
            if user.password != password:
                return Response({'error': 'Invalid password'}, status=401)
                # Generate token if user is authenticated
            refresh = RefreshToken.for_user(user)   
            return Response({
                    'userName': user.userName,
                    'Token': str(refresh.access_token), 
                        
                })

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    
class TicketListView(APIView):
    permission_classes = [IsAuthenticated]
    

    def get(self, request):
        print(request.user)
        # Get and clean the ticketStatus query parameter
        ticket_status = request.query_params.get('ticketStatus', '').strip()  # Strip any extra spaces
        print("Status from request:", ticket_status)  # Debugging print
        
        if ticket_status:
            # Filter tickets based on ticketStatus using case-insensitive match
            tickets = Ticket.objects.filter(ticketStatus=ticket_status)  # Use iexact for case-insensitivity
            print("Filtered tickets queryset:", tickets)  # Debugging print
            
            # If tickets exist, return them
            if tickets.exists():
                serializer = TicketSerializer(tickets, many=True)
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response({"msg": "No tickets found with the given status"}, status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({"msg": "ticket status needs to filter data"}, status=status.HTTP_400_BAD_REQUEST)
        

class TicketAddView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        #user = User.objects.get(id=request.data.get('clientObj'))
        if user.roleObj is None or user.roleObj.roleName!= 'client':
             # Debugging print
            return Response(
                {"msg": "you don't have permission to perform this operation"},
                status=status.HTTP_403_FORBIDDEN)

        ticket_data = request.data.copy()
        ticket_data['clientObj'] = user.id  # Set the client object to the logged-in user

        # Check if a ticket with the same ticketId already exists
        if Ticket.objects.filter(ticketId=ticket_data.get('ticketId')).exists():
            return Response({"msg": "ticketId already exists"}, status=status.HTTP_400_BAD_REQUEST)

        # Serialize and save the ticket data
        serializer = TicketSerializer(data=ticket_data)
        if serializer.is_valid():
            ticket = serializer.save()
            response_data = {
                "id": ticket.id,
                "clientObj": ticket.clientObj.id,
                "ticketId": ticket.ticketId,
                "issue": ticket.issue,
                "category": ticket.category,
                "createdAt": ticket.createdAt.strftime("%d-%m-%Y"),
                "isPriority": ticket.isPriority,
                "comment": ticket.comment,
                "ticketStatus": ticket.ticketStatus
            }
            return Response(response_data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class TicketUpdateView(APIView):
    permission_classes = [IsAuthenticated]

    def patch(self, request, id):
        # Ensure the authenticated user has the "admin" role
        user = request.user
        if user.roleObj is None or user.roleObj.roleName.lower() != 'client':
            return Response({"msg": "you don't have permission to perform this operation"}, status=status.HTTP_403_FORBIDDEN)
        
        # Get ticketStatus from the request data
        ticket_status = request.data.get('ticketStatus')
        if not ticket_status:
            return Response({"msg": "no data provided to update"}, status=status.HTTP_400_BAD_REQUEST)

        # Try to fetch the ticket with the given id
        try:
            ticket = Ticket.objects.get(id=id)
            # Update the ticketStatus and save
            ticket.ticketStatus = ticket_status
            ticket.save()
            
            # Serialize the updated ticket
            serializer = TicketSerializer(ticket)
            return Response(serializer.data, status=status.HTTP_200_OK)

        except Ticket.DoesNotExist:
            return Response({"msg": "ticket object not found"}, status=status.HTTP_404_NOT_FOUND)
        

class TicketDeleteView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request, id):
        user = request.user

        try:
            ticket = Ticket.objects.get(id=id)
        except Ticket.DoesNotExist:
            return Response(
                {"msg": "ticket object not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        # Only a client and the ticket creator can delete
        if user.roleObj is None or user.roleObj.roleName != 'client' or ticket.clientObj != user:
            return Response(
                {"msg": "you don't have permission to perform this operation"},
                status=status.HTTP_403_FORBIDDEN
            )

        ticket.delete()
        return Response({"msg":"Ticket is sucessfully deleted"},status=status.HTTP_204_NO_CONTENT)



