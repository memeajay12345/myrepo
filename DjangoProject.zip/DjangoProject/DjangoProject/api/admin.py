from django.contrib import admin
from .models import User, Role, Ticket

# Customize User Admin
@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id', 'userName', 'email', 'roleObj')
    search_fields = ('userName', 'email')
    list_filter = ('roleObj',)

# Customize Role Admin
@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ('id', 'roleName',)

# Customize Ticket Admin
@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'ticketId', 'clientObj', 'issue', 'category', 'isPriority',
        'ticketStatus', 'createdAt'
    )
    search_fields = ('ticketId', 'issue', 'category')
    list_filter = ('ticketStatus', 'isPriority', 'category', 'createdAt')
