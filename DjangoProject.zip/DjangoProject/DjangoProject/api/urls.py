from django.urls import path
from .views import loginView, TicketAddView, TicketListView, TicketUpdateView, TicketDeleteView

urlpatterns = [
    path('user/login', loginView.as_view()),
    path('ticket/add', TicketAddView.as_view()),
    path('ticket/list', TicketListView.as_view()),
    path('ticket/update/<int:id>', TicketUpdateView.as_view()),
    path('ticket/delete/<int:id>', TicketDeleteView.as_view()),
]
