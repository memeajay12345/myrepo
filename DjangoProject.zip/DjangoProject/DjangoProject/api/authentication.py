# api/authentication.py

from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken
from .proxy_user import ProxyUser
#from .models import User  # import your custom user model

class CustomJWTAuthentication(JWTAuthentication):
    def get_user(self, validated_token):
        user_id = validated_token.get("user_id")

        try:
            return ProxyUser.objects.get(id=user_id)
        except ProxyUser.DoesNotExist:
            raise InvalidToken({
                "detail": "User not found",
                "code": "user_not_found"
            })
